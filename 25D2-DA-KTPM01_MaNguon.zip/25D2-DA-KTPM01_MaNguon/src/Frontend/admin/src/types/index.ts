export interface NavigationItem {
  label: string;
  path: string;
  icon?: React.ReactNode;
}

export interface WarnItem {
  name: string;
  systolic?: number;
  diastolic?: number;
  heartRate?: number;
  bloodSugar?: number;
  respiratoryRate?: number;

  message?: string;
}

export interface ChartDataPoint {
  label: string;
  value: number;
}

export interface StatItem {
  id: string;
  label: string;
  value: number;
  type: "primary" | "warning" | "neutral";
}

export interface Patient {
  id: string;
  name: string;
  profileImageUrl?: string;
  email: string;
  phone: string;
  gender: string;
  dateOfBirth: string;
  address?: string;
  status: "active" | "inactive";
  cccd?: string;
  insuranceNumber?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  medicalHistory?: string;
  diseaseTypes?: { bloodPressure: boolean; glucose: boolean };
}

export interface ThresholdViolation {
  type: "temperature" | "systolic" | "diastolic" | "pulse" | "glucose" | "spo2" | "respiratoryRate";
  rule: string;
  observed: number;
  threshold: number;
  severity: "info" | "high";
}

export interface Alert {
  id: string;
  patientId: string;
  patientName: string;
  patientAvatar?: string;
  violations: ThresholdViolation[];
  status: "open" | "ack";
  severity: "info" | "high";
  acknowledgedBy?: string;
  acknowledgedAt?: string;
  doctorNote?: string;
  createdAt: string;
}

export interface Threshold {
  id: string;
  patientId: string;
  patientName?: string;
  temperatureMin?: number;
  temperatureMax?: number;
  systolicMin?: number;
  systolicMax?: number;
  diastolicMin?: number;
  diastolicMax?: number;
  pulseMin?: number;
  pulseMax?: number;
  glucoseMin?: number;
  glucoseMax?: number;
  spo2Min?: number;
  effectiveFrom: string;
  effectiveTo?: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  message: string;
  measurementId?: string;
  timestamp: Date;
}

export interface doctor {
  id: string;
  name: string;
  displayName?: string;
  academicDegree?: string;
  academicDegreeLabel?: string;
  professionalQualification?: string;
  professionalQualificationLabel?: string;
  academicTitle?: string;
  academicTitleLabel?: string;
  specialization: string;
  licenseNumber: string;
  workplace: string;
  department?: string;
  departmentId?: string;
  yearsOfExperience: number;
  status?: "active" | "inactive";
  profileImageUrl: string;
  gender: string;
  dateOfBirth: string;
  email?: string;
  phone?: string;
  patientCount?: number;
}

export interface Nurse {
  id: string;
  name: string;
  licenseNumber: string;
  workplace: string;
  department: string;
  departmentId?: string;
  yearsOfExperience: number;
  status?: "active" | "inactive";
  email?: string;
  phone?: string;
  profileImageUrl?: string;
  gender?: string;
  dateOfBirth?: string;
}

export interface SystemSettings {
  id: string;
  systemStatus: "online" | "offline" | "maintenance";
  maintenanceMessage?: string;
  allowNewRegistrations: boolean;
  maxPatientsPerDoctor: number;
  alertThresholdGlobal: {
    temperatureMin: number;
    temperatureMax: number;
    systolicMin: number;
    systolicMax: number;
    diastolicMin: number;
    diastolicMax: number;
    pulseMin: number;
    pulseMax: number;
    glucoseMin: number;
    glucoseMax: number;
    spo2Min: number;
  };
}

export interface Department {
  id: string;
  name: string;
  description: string;
  memberCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface Assignment {
  id: string;
  patientId: string;
  patientName?: string;
  patientCode?: string;
  patientPublicId?: string;
  doctorId?: string;
  doctorName?: string;
  nurseId?: string;
  nurseName?: string;
  assignedBy: string;
  createdAt: string;
  updatedAt: string;
}
