package repository

import (
	"context"
	"errors"
	"log"
	"time"

	"github.com/buonnguwaaa/Remote-Patient-Monitoring/Backend/internal/domain"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type thresholdRepository struct {
	col *mongo.Collection
}

type ThresholdRepository interface {
	Create(ctx context.Context, t *domain.Threshold) (*domain.Threshold, error)
	FindWithFilter(ctx context.Context, filter ThresholdFilter) ([]domain.Threshold, error)
	FindByID(ctx context.Context, id primitive.ObjectID) (*domain.Threshold, error)
	FindLatestActiveByPatientIDs(ctx context.Context, patientIDs []primitive.ObjectID) (map[primitive.ObjectID]*domain.Threshold, error)
	Update(ctx context.Context, t *domain.Threshold) (*domain.Threshold, error)
}

type ThresholdFilter struct {
	PatientID string
	DoctorID  string
	IsLatest  bool
}

func NewThresholdRepository(db *mongo.Database) ThresholdRepository {
	repo := &thresholdRepository{
		col: db.Collection("thresholds"),
	}
	if err := repo.ensureIndexes(context.Background()); err != nil {
		log.Printf("[WARN] failed to ensure threshold indexes: %v", err)
	}
	return repo
}

func (r *thresholdRepository) ensureIndexes(ctx context.Context) error {
	models := []mongo.IndexModel{
		{
			Keys: bson.D{
				{Key: "patientId", Value: 1},
				{Key: "effectiveFrom", Value: -1},
			},
			Options: options.Index().SetName("idx_threshold_patient_effective_from"),
		},
		{
			Keys: bson.D{
				{Key: "doctorId", Value: 1},
				{Key: "effectiveFrom", Value: -1},
			},
			Options: options.Index().SetName("idx_threshold_doctor_effective_from"),
		},
	}
	_, err := r.col.Indexes().CreateMany(ctx, models)
	return err
}

func (r *thresholdRepository) Create(ctx context.Context, t *domain.Threshold) (*domain.Threshold, error) {
	now := time.Now().UTC()

	// 1. Find the latest threshold for this patient
	filter := bson.M{
		"patientId": t.PatientID,
	}

	opts := options.FindOne().SetSort(bson.D{{Key: "effectiveFrom", Value: -1}})

	var last domain.Threshold
	err := r.col.FindOne(ctx, filter, opts).Decode(&last)

	// 2. If a previous threshold exists and EffectiveTo is nil, update it
	if err == nil && last.EffectiveTo == nil {
		update := bson.M{
			"$set": bson.M{
				"effectiveTo": now,
				"updatedAt":   now,
			},
		}

		_, uErr := r.col.UpdateByID(ctx, last.ID, update)
		if uErr != nil {
			return nil, uErr
		}
	}

	// If the error is NotFound – that's fine; we just insert new record
	if err != nil && !errors.Is(err, mongo.ErrNoDocuments) {
		// real error
		return nil, err
	}

	// 3. Insert the new threshold
	t.CreatedAt = now
	t.UpdatedAt = now

	result, err := r.col.InsertOne(ctx, t)
	if err != nil {
		return nil, err
	}

	t.ID = result.InsertedID.(primitive.ObjectID)
	return t, nil
}

func (r *thresholdRepository) FindWithFilter(ctx context.Context, filter ThresholdFilter) ([]domain.Threshold, error) {
	query := bson.M{}
	now := time.Now().UTC()

	if filter.PatientID != "" {
		pid, err := primitive.ObjectIDFromHex(filter.PatientID)
		if err == nil {
			query["patientId"] = pid
		}
	}

	if filter.DoctorID != "" {
		did, err := primitive.ObjectIDFromHex(filter.DoctorID)
		if err == nil {
			query["doctorId"] = did
		}
	}

	// --- CASE: GET LATEST RECORD ONLY ---
	if filter.IsLatest {
		query["effectiveFrom"] = bson.M{"$lte": now}
		query["$or"] = []bson.M{
			{"effectiveTo": bson.M{"$exists": false}},
			{"effectiveTo": nil},
			{"effectiveTo": bson.M{"$gt": now}},
		}

		opts := options.FindOne().
			SetSort(bson.D{{Key: "effectiveFrom", Value: -1}})

		var result domain.Threshold
		err := r.col.FindOne(ctx, query, opts).Decode(&result)
		if err != nil {
			if err == mongo.ErrNoDocuments {
				return []domain.Threshold{}, nil
			}
			return nil, err
		}

		return []domain.Threshold{result}, nil
	}

	// --- GET MULTIPLE ---
	opts := options.Find().
		SetSort(bson.D{{Key: "effectiveFrom", Value: -1}})

	cursor, err := r.col.Find(ctx, query, opts)
	if err != nil {
		return nil, err
	}
	defer cursor.Close(ctx)

	var results []domain.Threshold
	if err := cursor.All(ctx, &results); err != nil {
		return nil, err
	}

	return results, nil
}

// FindLatestActiveByPatientIDs returns the currently effective threshold for
// each of the given patients in a single aggregation, keyed by patient id.
func (r *thresholdRepository) FindLatestActiveByPatientIDs(ctx context.Context, patientIDs []primitive.ObjectID) (map[primitive.ObjectID]*domain.Threshold, error) {
	result := make(map[primitive.ObjectID]*domain.Threshold)
	if len(patientIDs) == 0 {
		return result, nil
	}

	now := time.Now().UTC()
	pipeline := mongo.Pipeline{
		{{Key: "$match", Value: bson.M{
			"patientId":     bson.M{"$in": patientIDs},
			"effectiveFrom": bson.M{"$lte": now},
			"$or": []bson.M{
				{"effectiveTo": bson.M{"$exists": false}},
				{"effectiveTo": nil},
				{"effectiveTo": bson.M{"$gt": now}},
			},
		}}},
		{{Key: "$sort", Value: bson.D{{Key: "effectiveFrom", Value: -1}}}},
		{{Key: "$group", Value: bson.M{
			"_id": "$patientId",
			"doc": bson.M{"$first": "$$ROOT"},
		}}},
	}

	cursor, err := r.col.Aggregate(ctx, pipeline)
	if err != nil {
		return nil, err
	}
	defer cursor.Close(ctx)

	var grouped []struct {
		PatientID primitive.ObjectID `bson:"_id"`
		Threshold domain.Threshold   `bson:"doc"`
	}
	if err := cursor.All(ctx, &grouped); err != nil {
		return nil, err
	}

	for i := range grouped {
		t := grouped[i].Threshold
		result[grouped[i].PatientID] = &t
	}
	return result, nil
}

func (r *thresholdRepository) FindByID(ctx context.Context, id primitive.ObjectID) (*domain.Threshold, error) {
	var threshold domain.Threshold
	if err := r.col.FindOne(ctx, bson.M{"_id": id}).Decode(&threshold); err != nil {
		return nil, err
	}

	return &threshold, nil
}

func (r *thresholdRepository) Update(ctx context.Context, t *domain.Threshold) (*domain.Threshold, error) {
	update := bson.M{
		"$set": bson.M{
			"temperatureMin":     t.TemperatureMin,
			"temperatureMax":     t.TemperatureMax,
			"heartRateMin":       t.HeartRateMin,
			"heartRateMax":       t.HeartRateMax,
			"respiratoryRateMin": t.RespiratoryRateMin,
			"respiratoryRateMax": t.RespiratoryRateMax,
			"spo2Min":            t.SpO2Min,
			"sysMin":             t.SysMin,
			"sysMax":             t.SysMax,
			"diaMin":             t.DiaMin,
			"diaMax":             t.DiaMax,
			"glucoseMin":         t.GlucoseMin,
			"glucoseMax":         t.GlucoseMax,
			"effectiveFrom":      t.EffectiveFrom,
			"effectiveTo":        t.EffectiveTo,
			"updatedAt":          time.Now().UTC(),
		},
	}

	_, err := r.col.UpdateByID(ctx, t.ID, update)
	if err != nil {
		return nil, err
	}

	var updated domain.Threshold
	if err := r.col.FindOne(ctx, bson.M{"_id": t.ID}).Decode(&updated); err != nil {
		return nil, err
	}

	return &updated, nil
}
