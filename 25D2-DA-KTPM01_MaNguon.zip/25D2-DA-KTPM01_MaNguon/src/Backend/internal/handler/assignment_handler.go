package handler

import (
	"context"
	"net/http"
	"strconv"
	"time"

	"github.com/buonnguwaaa/Remote-Patient-Monitoring/Backend/internal/constant"
	domain "github.com/buonnguwaaa/Remote-Patient-Monitoring/Backend/internal/domain/user"
	"github.com/buonnguwaaa/Remote-Patient-Monitoring/Backend/internal/dto"
	"github.com/buonnguwaaa/Remote-Patient-Monitoring/Backend/internal/service"
	"github.com/buonnguwaaa/Remote-Patient-Monitoring/Backend/internal/usecase"
	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type AssignmentHandler struct {
	service service.AssignmentService
}

func NewAssignmentHandler(service service.AssignmentService) *AssignmentHandler {
	return &AssignmentHandler{
		service: service,
	}
}

// AssignPatient assigns a patient to a doctor or nurse.
// @Summary Assign patient to doctor/nurse
// @Description Create or update an assignment between a patient and medical staff
// @Tags assignments
// @Accept json
// @Produce json
// @Param body body dto.AssignPatientRequest true "Assignment info"
// @Success 201 {object} map[string]interface{} "Assignment created successfully"
// @Failure 400 {object} map[string]string "Bad request"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Router /assignments/assign [post]
func (h *AssignmentHandler) AssignPatient(c *gin.Context) {
	var req dto.AssignPatientRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	adminID, exists := c.Get("userId")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": constant.MsgUnauthorized})
		return
	}

	ctx, cancel := context.WithTimeout(c.Request.Context(), 5*time.Second)
	defer cancel()

	// Map DTO to usecase input
	input := &usecase.AssignPatientInput{
		PatientID:  req.PatientID,
		DoctorID:   req.DoctorID,
		NurseID:    req.NurseID,
		AssignedBy: adminID.(string),
	}

	res, err := h.service.AssignPatient(ctx, input)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusCreated, gin.H{"data": res})
}

// @Summary Get assignments for the current doctor/nurse
// @Tags assignments
// @Produce json
// @Param page query int false "Page number (1-based). Omit for all results."
// @Param limit query int false "Items per page, default 10"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]string "Bad request"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 403 {object} map[string]string "Forbidden"
// @Router /assignments/me [get]
func (h *AssignmentHandler) GetMyAssignments(c *gin.Context) {
	userID, exists := c.Get("userId")
	role, existsRole := c.Get("role")

	if !exists || !existsRole {
		c.JSON(http.StatusUnauthorized, gin.H{"error": constant.MsgUnauthorized})
		return
	}

	ctx, cancel := context.WithTimeout(c.Request.Context(), 5*time.Second)
	defer cancel()

	roleVal := role.(domain.Role)

	if roleVal != domain.RoleDoctor && roleVal != domain.RoleNurse {
		c.JSON(http.StatusForbidden, gin.H{"error": constant.MsgOnlyDoctorOrNurse})
		return
	}

	// Read optional pagination params
	page, _ := strconv.Atoi(c.DefaultQuery("page", "0"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "10"))
	if limit < 1 {
		limit = 10
	}

	input := &usecase.GetAssignmentsByRoleInput{
		UserID: userID.(string),
		Role:   roleVal,
		Page:   page,
		Limit:  limit,
		Offset: 0,
	}

	// If page >= 1, use server-side pagination
	if page >= 1 {
		input.Offset = (page - 1) * limit
		res, total, err := h.service.GetAssignmentsByRolePaginated(ctx, input)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return
		}
		c.JSON(http.StatusOK, gin.H{"data": res, "total": total})
		return
	}

	// No pagination — return all (backward compatible)
	res, err := h.service.GetAssignmentsByRole(ctx, input)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": res})
}

// @Summary Get all assignments (admin only)
// @Tags assignments
// @Produce json
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 403 {object} map[string]string "Forbidden"
// @Router /assignments [get]
func (h *AssignmentHandler) GetAllAssignments(c *gin.Context) {
	ctx, cancel := context.WithTimeout(c.Request.Context(), 5*time.Second)
	defer cancel()

	res, err := h.service.GetAllAssignments(ctx)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": res})
}

// @Summary Delete an assignment by ID
// @Tags assignments
// @Param id path string true "Assignment ID"
// @Success 200 {object} map[string]interface{} "Assignment deleted successfully"
// @Failure 400 {object} map[string]string "Bad request"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 403 {object} map[string]string "Forbidden"
// @Router /assignments/{id} [delete]
func (h *AssignmentHandler) DeleteAssignment(c *gin.Context) {
	assignmentID := c.Param("id")
	if assignmentID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": constant.MsgMissingAssignmentID})
		return
	}

	ctx, cancel := context.WithTimeout(c.Request.Context(), 5*time.Second)
	defer cancel()

	if err := h.service.DeleteAssignmentByID(ctx, &usecase.DeleteAssignmentInput{AssignmentID: assignmentID}); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Assignment deleted successfully"})
}
// GetMyCareTeam returns the assigned doctor and nurse for the current patient.
// @Summary Get assigned care team for the current patient
// @Description Returns the detailed info of the doctor and nurse currently assigned to the patient
// @Tags assignments
// @Accept json
// @Failure 403 {object} map[string]interface{}
// @Router /api/v1/assignments/my-care-team [get]
func (h *AssignmentHandler) GetMyCareTeam(c *gin.Context) {
	ctx, cancel := context.WithTimeout(c.Request.Context(), 5*time.Second)
	defer cancel()

	userRole, exists := c.Get("role")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": constant.MsgUnauthorized})
		return
	}

	roleVal, ok := userRole.(domain.Role)
	if !ok || roleVal != domain.RolePatient {
		c.JSON(http.StatusForbidden, gin.H{"error": constant.MsgOnlyPatient})
		return
	}

	rawUserID, exists := c.Get("userId")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": constant.MsgUnauthorized})
		return
	}
	userIDStr, ok := rawUserID.(string)
	if !ok {
		c.JSON(http.StatusUnauthorized, gin.H{"error": constant.MsgUnauthorized})
		return
	}

	userID, err := primitive.ObjectIDFromHex(userIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User ID"})
		return
	}

	careTeam, err := h.service.GetMyCareTeam(ctx, userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": careTeam})
}

// GetDoctorPatientCounts returns the number of patients currently assigned to each doctor.
// @Summary Get patient counts per doctor
// @Description Returns a map of doctorId -> patient count for all doctors with active assignments
// @Tags assignments
// @Produce json
// @Success 200 {object} map[string]interface{} "Doctor patient counts"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 403 {object} map[string]string "Forbidden"
// @Router /assignments/doctor-patient-counts [get]
func (h *AssignmentHandler) GetDoctorPatientCounts(c *gin.Context) {
	ctx, cancel := context.WithTimeout(c.Request.Context(), 5*time.Second)
	defer cancel()

	counts, err := h.service.GetDoctorPatientCounts(ctx)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": counts})
}

// GetNursePatientCounts returns the number of patients currently assigned to each nurse.
func (h *AssignmentHandler) GetNursePatientCounts(c *gin.Context) {
	ctx, cancel := context.WithTimeout(c.Request.Context(), 5*time.Second)
	defer cancel()

	counts, err := h.service.GetNursePatientCounts(ctx)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": counts})
}
