package router

import (
	"github.com/buonnguwaaa/Remote-Patient-Monitoring/Backend/internal/container"
	domain "github.com/buonnguwaaa/Remote-Patient-Monitoring/Backend/internal/domain/user"
	"github.com/buonnguwaaa/Remote-Patient-Monitoring/Backend/internal/middleware"
	"github.com/gin-gonic/gin"
)

func RegisterAssignmentRoutes(r *gin.Engine, c *container.MainServerContainer) {
	assignGroup := r.Group("/assignments")
	assignGroup.Use(middleware.JWTAuthMiddleware(c.JWTManager, c.TokenBlacklistRepo))
	{
		assignGroup.POST("/assign", middleware.RequireRoles(domain.RoleAdmin), c.AssignmentHandler.AssignPatient)
		assignGroup.GET("", middleware.RequireRoles(domain.RoleAdmin), c.AssignmentHandler.GetAllAssignments)
		assignGroup.GET("/me", middleware.RequireRoles(domain.RoleDoctor, domain.RoleNurse), c.AssignmentHandler.GetMyAssignments)
		assignGroup.GET("/my-care-team", middleware.RequireRoles(domain.RolePatient), c.AssignmentHandler.GetMyCareTeam)
		assignGroup.GET("/doctor-patient-counts", middleware.RequireRoles(domain.RoleAdmin), c.AssignmentHandler.GetDoctorPatientCounts)
		assignGroup.GET("/nurse-patient-counts", middleware.RequireRoles(domain.RoleAdmin), c.AssignmentHandler.GetNursePatientCounts)
		assignGroup.DELETE("/:id", middleware.RequireRoles(domain.RoleAdmin), c.AssignmentHandler.DeleteAssignment)
	}
}

